/**
 * File based repository storage.
 */
package org.eclipse.jgit.internal.storage.file;
