/**
 * Git fsck support.
 */
package org.eclipse.jgit.internal.fsck;
