/**
 * Distributed consensus system built on Git.
 */
package org.eclipse.jgit.internal.ketch;
