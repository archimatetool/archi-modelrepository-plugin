/**
 * Reading and editing the directory cache (index).
 */
package org.eclipse.jgit.dircache;
