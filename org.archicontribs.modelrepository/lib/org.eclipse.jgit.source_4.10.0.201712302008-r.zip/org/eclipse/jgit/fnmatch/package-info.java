/**
 * File name matcher.
 */
package org.eclipse.jgit.fnmatch;
