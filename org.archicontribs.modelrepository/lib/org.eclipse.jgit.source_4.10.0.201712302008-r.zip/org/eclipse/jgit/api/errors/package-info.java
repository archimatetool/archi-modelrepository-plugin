/**
 * Exceptions thrown by API commands.
 */
package org.eclipse.jgit.api.errors;
