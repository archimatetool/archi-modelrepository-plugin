/**
 * Computing blame/annotate information of files.
 */
package org.eclipse.jgit.blame;
