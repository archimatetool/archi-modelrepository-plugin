/**
 * Content and commit history merge algorithms.
 */
package org.eclipse.jgit.merge;
